# -*- coding: cp1252 -*-
import urllib,re,string,sys,os,urllib2
import xbmc,xbmcgui,xbmcaddon,xbmcplugin
from resources.libs import main

#Mash Up - by Mash2k3 2012.

addon_id = 'plugin.video.movie25'
selfAddon = xbmcaddon.Addon(id=addon_id)
art = main.art
prettyName = 'WatchSeriesHD'

def MAINWATCHHD(index=False):
        main.addDir('Search','s',808,art+'/search.png',index=index)
        main.addDir('Home','http://watchserieshd.eu/',805,art+'/.png',index=index)
        main.addDir('Latest 350 eps','http://watchserieshd.eu/2009/10/recent-episodes.html',804,art+'/.png',index=index)
        #main.addDir('A-Z','s',803,art+'/az.png',index=index)
        main.addDir('Other Shows','http://watchserieshd.eu/category/not-in-homepage',810,art+'/.png',index=index)
        main.VIEWSB()

############ ----  A-Z  (NOT THE BEST WAY BUT WORKS FOR NOW, WILL CLEAN UP LATER ---  ###############################    

def AtoZWATCHHD(index=False):
    main.addDir('09','http://watchserieshd.eu/2005/07/index.html#goto_0-9',812,art+'/09.png',index=index)
    main.addDir('A','http://watchserieshd.eu/2005/07/index.html#goto_A',813,art+'/A.png',index=index)
    main.addDir('B','http://watchserieshd.eu/2005/07/index.html#goto_B',814,art+'/B.png',index=index)
    main.addDir('C','http://watchserieshd.eu/2005/07/index.html#goto_C',815,art+'/C.png',index=index)
    main.addDir('D','http://watchserieshd.eu/2005/07/index.html#goto_D',816,art+'/D.png',index=index)
    main.addDir('E','http://watchserieshd.eu/2005/07/index.html#goto_E',817,art+'/E.png',index=index)
    main.addDir('F','http://watchserieshd.eu/2005/07/index.html#goto_F',818,art+'/F.png',index=index)
    main.addDir('G','http://watchserieshd.eu/2005/07/index.html#goto_G',819,art+'/G.png',index=index)
    main.addDir('H','http://watchserieshd.eu/2005/07/index.html#goto_H',820,art+'/H.png',index=index)
    main.addDir('I','http://watchserieshd.eu/2005/07/index.html#goto_I',821,art+'/I.png',index=index)
    main.addDir('J','http://watchserieshd.eu/2005/07/index.html#goto_J',822,art+'/J.png',index=index)
    main.addDir('K','http://watchserieshd.eu/2005/07/index.html#goto_K',823,art+'/K.png',index=index)
    main.addDir('L','http://watchserieshd.eu/2005/07/index.html#goto_L',824,art+'/L.png',index=index)
    main.addDir('M','http://watchserieshd.eu/2005/07/index.html#goto_M',825,art+'/M.png',index=index)
    main.addDir('N','http://watchserieshd.eu/2005/07/index.html#goto_N',826,art+'/N.png',index=index)
    main.addDir('O','http://watchserieshd.eu/2005/07/index.html#goto_O',827,art+'/O.png',index=index)
    main.addDir('P','http://watchserieshd.eu/2005/07/index.html#goto_P',828,art+'/P.png',index=index)
    main.addDir('Q','http://watchserieshd.eu/2005/07/index.html#goto_Q',829,art+'/Q.png',index=index)
    main.addDir('R','http://watchserieshd.eu/2005/07/index.html#goto_R',830,art+'/R.png',index=index)
    main.addDir('S','http://watchserieshd.eu/2005/07/index.html#goto_S',831,art+'/S.png',index=index)
    main.addDir('T','http://watchserieshd.eu/2005/07/index.html#goto_T',832,art+'/T.png',index=index)
    main.addDir('U','http://watchserieshd.eu/2005/07/index.html#goto_U',833,art+'/U.png',index=index)
    main.addDir('V','http://watchserieshd.eu/2005/07/index.html#goto_V',834,art+'/V.png',index=index)
    main.addDir('W','http://watchserieshd.eu/2005/07/index.html#goto_W',835,art+'/W.png',index=index)
    main.addDir('X','http://watchserieshd.eu/2005/07/index.html#goto_X',836,art+'/X.png',index=index)
    main.addDir('Y','http://watchserieshd.eu/2005/07/index.html#goto_Y',837,art+'/Y.png',index=index)
    main.addDir('Z','http://watchserieshd.eu/2005/07/index.html#goto_Z',838,art+'/Z.png',index=index)
    main.VIEWSB()


def NUMBER(murl,index=False):
        link=main.OPENURL(murl)
        link=link.replace('\r','').replace('\n','').replace('\t','')
        match=re.compile('>0-9</span>(.+?)>A</span>').findall(link)
        if match:                
         match2=re.compile('<li><a href="([^"]*)">([^"]*)</a></li>').findall(match[0])
         for url,name in match2:
            main.addDirTE(name,url,807,'','','','','','')
def A(murl,index=False):
        link=main.OPENURL(murl)
        link=link.replace('\r','').replace('\n','').replace('\t','')
        match=re.compile('>A</span>(.+?)>B</span>').findall(link)
        if match:
         match2=re.compile('<li><a href="([^"]*)">([^"]*)</a></li>').findall(match[0])
         for url,name in match2:
            main.addDirTE(name,url,807,'','','','','','')
def B(murl,index=False):
        link=main.OPENURL(murl)
        link=link.replace('\r','').replace('\n','').replace('\t','')
        match=re.compile('>B</span>(.+?)>C</span>').findall(link)
        if match:
         match2=re.compile('<li><a href="([^"]*)">([^"]*)</a></li>').findall(match[0])
         for url,name in match2:
            main.addDirTE(name,url,807,'','','','','','')
def C(murl,index=False):
        link=main.OPENURL(murl)
        link=link.replace('\r','').replace('\n','').replace('\t','')
        match=re.compile('>C</span>(.+?)>D</span>').findall(link)
        if match:
         match2=re.compile('<li><a href="([^"]*)">([^"]*)</a></li>').findall(match[0])
         for url,name in match2:
            main.addDirTE(name,url,807,'','','','','','')
def D(murl,index=False):
        link=main.OPENURL(murl)
        link=link.replace('\r','').replace('\n','').replace('\t','')
        match=re.compile('>D</span>(.+?)>E</span>').findall(link)
        if match:
         match2=re.compile('<li><a href="([^"]*)">([^"]*)</a></li>').findall(match[0])
         for url,name in match2:
            main.addDirTE(name,url,807,'','','','','','')
def E(murl,index=False):
        link=main.OPENURL(murl)
        link=link.replace('\r','').replace('\n','').replace('\t','')
        match=re.compile('>E</span>(.+?)>F</span>').findall(link)
        if match:
         match2=re.compile('<li><a href="([^"]*)">([^"]*)</a></li>').findall(match[0])
         for url,name in match2:
            main.addDirTE(name,url,807,'','','','','','')
def F(murl,index=False):
        link=main.OPENURL(murl)
        link=link.replace('\r','').replace('\n','').replace('\t','')
        match=re.compile('>F</span>(.+?)>G</span>').findall(link)
        if match:
         match2=re.compile('<li><a href="([^"]*)">([^"]*)</a></li>').findall(match[0])
         for url,name in match2:
            main.addDirTE(name,url,807,'','','','','','')
def G(murl,index=False):
        link=main.OPENURL(murl)
        link=link.replace('\r','').replace('\n','').replace('\t','')
        match=re.compile('>G</span>(.+?)>H</span>').findall(link)
        if match:
         match2=re.compile('<li><a href="([^"]*)">([^"]*)</a></li>').findall(match[0])
         for url,name in match2:
            main.addDirTE(name,url,807,'','','','','','')
def H(murl,index=False):
        link=main.OPENURL(murl)
        link=link.replace('\r','').replace('\n','').replace('\t','')
        match=re.compile('>H</span>(.+?)>I</span>').findall(link)
        if match:
         match2=re.compile('<li><a href="([^"]*)">([^"]*)</a></li>').findall(match[0])
         for url,name in match2:
            main.addDirTE(name,url,807,'','','','','','')
def I(murl,index=False):
        link=main.OPENURL(murl)
        link=link.replace('\r','').replace('\n','').replace('\t','')
        match=re.compile('>I</span>(.+?)>J</span>').findall(link)
        if match:
         match2=re.compile('<li><a href="([^"]*)">([^"]*)</a></li>').findall(match[0])
         for url,name in match2:
            main.addDirTE(name,url,807,'','','','','','')
def J(murl,index=False):
        link=main.OPENURL(murl)
        link=link.replace('\r','').replace('\n','').replace('\t','')
        match=re.compile('J</span>(.+?)>K</span>').findall(link)
        if match:
         match2=re.compile('<li><a href="([^"]*)">([^"]*)</a></li>').findall(match[0])
         for url,name in match2:
            main.addDirTE(name,url,807,'','','','','','')
def K(murl,index=False):
        link=main.OPENURL(murl)
        link=link.replace('\r','').replace('\n','').replace('\t','')
        match=re.compile('>K</span>(.+?)>L</span>').findall(link)
        if match:
         match2=re.compile('<li><a href="([^"]*)">([^"]*)</a></li>').findall(match[0])
         for url,name in match2:
            main.addDirTE(name,url,807,'','','','','','')
def L(murl,index=False):
        link=main.OPENURL(murl)
        link=link.replace('\r','').replace('\n','').replace('\t','')
        match=re.compile('>0-9</span>(.+?)>A</span>').findall(link)
        if match:
         match2=re.compile('<li><a href="([^"]*)">([^"]*)</a></li>').findall(match[0])
         for url,name in match2:
            main.addDirTE(name,url,807,'','','','','','')
def M(murl,index=False):
        link=main.OPENURL(murl)
        link=link.replace('\r','').replace('\n','').replace('\t','')
        match=re.compile('>M</span>(.+?)>N</span>').findall(link)
        if match:
         match2=re.compile('<li><a href="([^"]*)">([^"]*)</a></li>').findall(match[0])
         for url,name in match2:
            main.addDirTE(name,url,807,'','','','','','')
def N(murl,index=False):
        link=main.OPENURL(murl)
        link=link.replace('\r','').replace('\n','').replace('\t','')
        match=re.compile('>N</span>(.+?)>O</span>').findall(link)
        if match:
         match2=re.compile('<li><a href="([^"]*)">([^"]*)</a></li>').findall(match[0])
         for url,name in match2:
            main.addDirTE(name,url,807,'','','','','','')
def O(murl,index=False):
        link=main.OPENURL(murl)
        link=link.replace('\r','').replace('\n','').replace('\t','')
        match=re.compile('>O</span>(.+?)>P</span>').findall(link)
        if match:
         match2=re.compile('<li><a href="([^"]*)">([^"]*)</a></li>').findall(match[0])
         for url,name in match2:
            main.addDirTE(name,url,807,'','','','','','')
def P(murl,index=False):
        link=main.OPENURL(murl)
        link=link.replace('\r','').replace('\n','').replace('\t','')
        match=re.compile('>P</span>(.+?)>Q</span>').findall(link)
        if match:
         match2=re.compile('<li><a href="([^"]*)">([^"]*)</a></li>').findall(match[0])
         for url,name in match2:
            main.addDirTE(name,url,807,'','','','','','')
def Q(murl,index=False):
        link=main.OPENURL(murl)
        link=link.replace('\r','').replace('\n','').replace('\t','')
        match=re.compile('>Q</span>(.+?)>R</span>').findall(link)
        if match:
         match2=re.compile('<li><a href="([^"]*)">([^"]*)</a></li>').findall(match[0])
         for url,name in match2:
            main.addDirTE(name,url,807,'','','','','','')
def R(murl,index=False):
        link=main.OPENURL(murl)
        link=link.replace('\r','').replace('\n','').replace('\t','')
        match=re.compile('>R</span>(.+?)>S</span>').findall(link)
        if match:
         match2=re.compile('<li><a href="([^"]*)">([^"]*)</a></li>').findall(match[0])
         for url,name in match2:
            main.addDirTE(name,url,807,'','','','','','')
def S(murl,index=False):
        link=main.OPENURL(murl)
        link=link.replace('\r','').replace('\n','').replace('\t','')
        match=re.compile('>S</span>(.+?)>T</span>').findall(link)
        if match:
         match2=re.compile('<li><a href="([^"]*)">([^"]*)</a></li>').findall(match[0])
         for url,name in match2:
            main.addDirTE(name,url,807,'','','','','','')
def T(murl,index=False):
        link=main.OPENURL(murl)
        link=link.replace('\r','').replace('\n','').replace('\t','')
        match=re.compile('>T</span>(.+?)>U</span>').findall(link)
        if match:
         match2=re.compile('<li><a href="([^"]*)">([^"]*)</a></li>').findall(match[0])
         for url,name in match2:
            main.addDirTE(name,url,807,'','','','','','')
def U(murl,index=False):
        link=main.OPENURL(murl)
        link=link.replace('\r','').replace('\n','').replace('\t','')
        match=re.compile('>U</span>(.+?)>V</span>').findall(link)
        if match:
         match2=re.compile('<li><a href="([^"]*)">([^"]*)</a></li>').findall(match[0])
         for url,name in match2:
            main.addDirTE(name,url,807,'','','','','','')
def V(murl,index=False):
        link=main.OPENURL(murl)
        link=link.replace('\r','').replace('\n','').replace('\t','')
        match=re.compile('>V</span>(.+?)>W</span>').findall(link)
        if match:
         match2=re.compile('<li><a href="([^"]*)">([^"]*)</a></li>').findall(match[0])
         for url,name in match2:
            main.addDirTE(name,url,807,'','','','','','')
def W(murl,index=False):
        link=main.OPENURL(murl)
        link=link.replace('\r','').replace('\n','').replace('\t','')
        match=re.compile('>W</span>(.+?)>X</span>').findall(link)
        if match:
         match2=re.compile('<li><a href="([^"]*)">([^"]*)</a></li>').findall(match[0])
         for url,name in match2:
            main.addDirTE(name,url,807,'','','','','','')
def X(murl,index=False):
        link=main.OPENURL(murl)
        link=link.replace('\r','').replace('\n','').replace('\t','')
        match=re.compile('>X</span>(.+?)>Y</span>').findall(link)
        if match:
         match2=re.compile('<li><a href="([^"]*)">([^"]*)</a></li>').findall(match[0])
         for url,name in match2:
            main.addDirTE(name,url,807,'','','','','','')
def Y(murl,index=False):
        link=main.OPENURL(murl)
        link=link.replace('\r','').replace('\n','').replace('\t','')
        match=re.compile('>Y</span>(.+?)>Z</span>').findall(link)
        if match:
         match2=re.compile('<li><a href="([^"]*)">([^"]*)</a></li>').findall(match[0])
         for url,name in match2:
            main.addDirTE(name,url,807,'','','','','','')
def Z(murl,index=False):
        link=main.OPENURL(murl)
        link=link.replace('\r','').replace('\n','').replace('\t','')
        match=re.compile('>Z</span>(.+?)class="PostMetadataFooter">').findall(link)
        if match:
         match2=re.compile('<li><a href="([^"]*)">([^"]*)</a></li>').findall(match[0])
         for url,name in match2:
            main.addDirTE(name,url,807,'','','','','','')




def LISTAZHD(murl,index=False):
        link=main.OPENURL(murl)
        link=link.replace('\r','').replace('\n','').replace('\t','')
        match=re.compile('Delete').findall(link)
        for date, url, name in match:
            main.addDirTE(date+' '+name,url,807,'','','','','','')

def LISTWATCHHD(murl,index=False):
        link=main.OPENURL(murl)
        link=link.replace('\r','').replace('\n','').replace('\t','')
        match=re.compile('<li>([^"]*)<a href="([^"]*)">([^"]*)</a> </li>').findall(link)
        dialogWait = xbmcgui.DialogProgress()
        ret = dialogWait.create('Please wait until Show list is cached.')
        totalLinks = len(match)
        loadedLinks = 0
        remaining_display = 'Episodes loaded :: [B]'+str(loadedLinks)+' / '+str(totalLinks)+'[/B].'
        dialogWait.update(0,'[B]Will load instantly from now on[/B]',remaining_display)
        for date, url, name in match:
            main.addDirTE(date+' '+name,url,807,'','','','','','')

        dialogWait.close()
        del dialogWait

def LISTWATCHHDHOME(murl,index=False):
        link=main.OPENURL(murl)
        link=link.replace('\r','').replace('\n','').replace('\t','')
        match=re.compile('class="PostHeader"><a href="([^"]*)" rel="bookmark" title=".+?">([^"]*)</a>.+?<img src="([^"]*)".+?alt="PostDateIcon"/><span style=".+?">([^"]*)</span>').findall(link)
        dialogWait = xbmcgui.DialogProgress()
        ret = dialogWait.create('Please wait until Show list is cached.')
        totalLinks = len(match)
        loadedLinks = 0
        remaining_display = 'Episodes loaded :: [B]'+str(loadedLinks)+' / '+str(totalLinks)+'[/B].'
        dialogWait.update(0,'[B]Will load instantly from now on[/B]',remaining_display)
        for url,title,thumb,date in match:
            main.addDirTE(date+' : '+ title,url,807,thumb,'','','','','')

        dialogWait.close()
        del dialogWait

        nextpage=match=re.compile('<a href="([^"]*)" class="next">&raquo;</a>').findall(link)
        for url in nextpage:
           main.addDir('[COLOR blue] NEXT PAGE >> [/COLOR]',url,805,'' )

def LISTWATCHHDOTR(murl,index=False):
        link=main.OPENURL(murl)
        link=link.replace('\r','').replace('\n','').replace('\t','')
        match=re.compile('class="PostHeader"><a href="([^"]*)" rel="bookmark" title=".+?">([^"]*)</a></span>.+?<img src="([^"]*)".+?PostDateIcon"/>([^"]*) [|]').findall(link)
        dialogWait = xbmcgui.DialogProgress()
        ret = dialogWait.create('Please wait until Show list is cached.')
        totalLinks = len(match)
        loadedLinks = 0
        remaining_display = 'Episodes loaded :: [B]'+str(loadedLinks)+' / '+str(totalLinks)+'[/B].'
        dialogWait.update(0,'[B]Will load instantly from now on[/B]',remaining_display)
        for url,title,thumb,date in match:
            main.addDirTE(date+' : '+ title,url,807,thumb,'','','','','')

        dialogWait.close()
        del dialogWait

        nextpage=match=re.compile('<a href="([^"]*)" class="next">&raquo;</a>').findall(link)
        for url in nextpage:
           main.addDir('[COLOR blue] NEXT PAGE >> [/COLOR]',url,810,'' )
           


def superSearch(encode,type):
    try:
        returnList=[]
        surl='http://watchseries.ag/search/'+encode
        epi = re.search('(?i)s(\d+?)e(\d+?)$',encode)
        if epi:
            epistring = encode.rpartition('%20')[2].upper()
            e = int(epi.group(2))
            s = int(epi.group(1))
            encodewithoutepi = urllib.quote(re.sub('(?i)(\ss(\d+)e(\d+))|(Season(.+?)Episode)|(\d+)x(\d+)','',urllib.unquote(encode)).strip())
            encode=encodewithoutepi+' season '+str(s)+' episode '+str(e)
            site = 'site:http://watchseries.ag/'
            results = main.SearchGoogle(urllib.unquote(encode), site)
            for res in results:
                t = res.title.encode('utf8').strip('...')
                u = res.url.encode('utf8')
                if type == 'TV':
                    if re.search('(?sim)season '+str(s)+' episode '+str(e),t):
                        t = re.sub('(?i)^[a-z] - (.*?)','\\1',t)
                        t = re.sub('(.*\)).*','\\1',t)
                        t= t.strip(" -").replace("-","").replace(" WatchSeries.lt","").replace(" Watch Series","").replace("Watch Online ","").replace("Watch Online","").replace("  "," ")
                        name=re.sub('\((\d+)x(\d+)\)','',t,re.I)
                        episode = re.search('Seas(on)?\.? (\d+).*?Ep(isode)?\.? (\d+)',name, re.I)
                        if(episode):
                            e = str(episode.group(4))
                            if(len(e)==1): e = "0" + e
                            s = episode.group(2)
                            if(len(s)==1): s = "0" + s
                            name = re.sub('Seas(on)?\.? (\d+).*?Ep(isode)?\.? (\d+)',"S" + s + "E" + e,name,re.I).strip()
                            name = re.sub('(?i)(s\d+e\d+\s?)(.*?)$','\\1[COLOR blue]\\2[/COLOR]',name)
                        returnList.append((name,prettyName,u,'',575,True))
                        return returnList
        link=main.OPENURL(surl,verbose=False)
        link=link.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','')
        match=re.compile('<img src="([^"]+?)">               </a>.*?<a title="[^"]+?" href="([^<]+)"><b>(.+?)</b>',re.DOTALL).findall(link)
        for thumb,url,name in match:
            url = 'http://watchseries.ag' + url
            returnList.append((name,prettyName,url,thumb,578,True))
        return returnList
    except: return []
            


def SearchhistoryWSHD():
    seapath=os.path.join(main.datapath,'Search')
    SeaFile=os.path.join(seapath,'SearchHistoryTV')
    if not os.path.exists(SeaFile):
        SEARCHWSHD()
    else:
        main.addDir('Search Shows','###',809,art+'/search.png')
        main.addDir('Clear History',SeaFile,128,art+'/cleahis.png')
        thumb=art+'/link.png'
        searchis=re.compile('search="(.+?)",').findall(open(SeaFile,'r').read())
        for seahis in reversed(searchis):
            url=seahis
            seahis=seahis.replace('%20',' ')
            main.addDir(seahis,url,809,thumb)

            

def SEARCHWSHD(url = '',index=False):
        encode = main.updateSearchFile(url,'TV')
        if not encode: return False   
        surl='http://watchserieshd.eu/?s='+encode+'&search=Submit'
        link=main.OPENURL(surl)
        link=link.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','').replace('#038;','')
        match=re.compile('class="PostHeader"><a href="([^"]*)" rel="bookmark" title=".+?">([^"]*)</a></span>.+?<img src="([^"]*)".+?PostDateIcon"/>([^"]*) [|]').findall(link)
        for url,name,thumb,date in match:
         name=name.replace('&#8242;',"'")
         main.addDirTE(name+'  '+"[COLOR red]" + date + '[/COLOR]',url,811,'','','','','','')

        paginate=re.compile('<li><a href="([^"]*)" class="next">&raquo;</a>').findall(link)
        if paginate:
         xurl=paginate[0]       
         main.addDir('[COLOR blue]Next > [/COLOR]',xurl,810,art+'/next2.png',index=index)
                
                 
             
        
def LISTHOSTHD(name,murl):
        link=main.OPENURL(murl)
        link=link.replace('\r','').replace('\n','').replace('\t','')
        if selfAddon.getSetting("hide-download-instructions") != "true":
            main.addLink("[COLOR yellow]For Download Options, Bring up Context Menu Over Selected Link.[/COLOR]",'','')
        match=re.compile('<a target="_blank" id="hovered" href="([^"]*)">([^"]*)<span style="margin-left: 1px"></span></a>').findall(link)
        for url,host in match:
          EMBED(url,host,name)
          #main.addDown2(name.strip()+" [COLOR blue]"+host.upper()+"[/COLOR]",url,811,art+'/hosts/'+host+'.png',art+'/hosts/'+host+'.png')     


def EMBED(url,host,name):
    link=main.OPENURL(url)
    link=link
    match=re.compile('action="([^"]*)"></form>').findall(link)
    for url in match:
      main.addDown2(name.strip()+" [COLOR blue]"+host.upper()+"[/COLOR]",url,811,art+'/hosts/'+host+'.png',art+'/hosts/'+host+'.png')
      


def PLAYB(name,murl):
    ok=True
    hname=name
    name  = name.split('[COLOR blue]')[0]
    name  = name.split('[COLOR red]')[0]
    infoLabels = main.GETMETAT(name,'','','')
    video_type='movie'
    season=''
    episode=''
    img=infoLabels['cover_url']
    fanart =infoLabels['backdrop_url']
    imdb_id=infoLabels['imdb_id']
    infolabels = { 'supports_meta' : 'true', 'video_type':video_type, 'name':str(infoLabels['title']), 'imdb_id':str(infoLabels['imdb_id']), 'season':str(season), 'episode':str(episode), 'year':str(infoLabels['year']) }

    try:
        xbmc.executebuiltin("XBMC.Notification(Please Wait!,Resolving Link,3000)")
        stream_url = main.resolve_url(murl)

        infoL={'Title': infoLabels['metaName'], 'Plot': infoLabels['plot'], 'Genre': infoLabels['genre']}
        # play with bookmark
        from resources.universal import playbackengine
        player = playbackengine.PlayWithoutQueueSupport(resolved_url=stream_url, addon_id=addon_id, video_type=video_type, title=str(infoLabels['title']),season=str(season), episode=str(episode), year=str(infoLabels['year']),img=img,infolabels=infoL, watchedCallbackwithParams=main.WatchedCallbackwithParams,imdb_id=imdb_id)
        #WatchHistory
        if selfAddon.getSetting("whistory") == "true":
            from resources.universal import watchhistory
            wh = watchhistory.WatchHistory('plugin.video.movie25')
            wh.add_item(hname+' '+'[COLOR green]Movie25[/COLOR]', sys.argv[0]+sys.argv[2], infolabels=infolabels, img=img, fanart=fanart, is_folder=False)
        player.KeepAlive()
        return ok
    except Exception, e:
        if stream_url != False:
                main.ErrorReport(e)
        return ok


def OPEN_URL(url):
    req = urllib2.Request(url)
    import time
    #time.sleep(6)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    #link=response.read().replace('&amp;','&').replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','').replace('%3A',':').replace('%2F','/').replace('%3F','?').replace('%3D','=').replace('%26','&').replace('%3B',';').replace('crawler','')#.replace(';v=1','')
    link=response.read().replace('%3A',':').replace('%2F','/').replace('%3F','?').replace('%3D','=').replace('%26','&').replace('%3B',';').replace('&amp;','&').replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','').replace('#038;','')
    response.close()
    return link


